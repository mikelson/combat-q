/*
 * Source code for the Edit Character Form.
 */

#include "Main.h"
#include "CombatQOGC.h"
#include "Performer.h"

Character* character = NULL;

/* Pop up form for editing existing character. */ 
void Character::popupEditForm(void) {
	character = this;
	FrmPopupForm(EditCharFormID);
}

/* Pop up form for editing character. If argument is NULL, create a charcter. */
void FrmPopupEditCharForm(void) {
	character = NULL;
	FrmPopupForm(EditCharFormID);
}

/* 
 * Process input-event to form.
 */
Boolean EventHandlerEditCharForm(EventPtr event)
{
    Boolean handled = false;
    FormType* form;
	FieldType* field;
    switch (event->eType) {
        case frmOpenEvent: // draw the form on the screen
            form = FrmGetActiveForm();
            FrmDrawForm(form);

			if (character == NULL) { // creating a new character - put default values in fields
				Char numS[maxStrIToALen];

				/* Name */
        		StrIToA(numS,counterCharacterName);
        		// create base and final strings
        		Char* base = "NPC ";
        		Char name[StrLen(base)+StrSize(numS)];
        		// concatenate base name and number strings
        		StrCopy(name, base);
        		StrCat(name, numS);
				FldSet(form,NameFieldID,name);
			
				/* Modifier */
				StrIToA(numS, 0);
				FldSet(form,ModifierFieldID,numS);
				
				/* Effect Name Counter */
				StrIToA(numS, 1);
				FldSet(form,CountFieldID,numS);
				
				/* Default Effect Duration */
				StrIToA(numS, 3);
				FldSet(form,DurationFieldID,numS);
				
				/* Check Boxes */
				// TODO - F2 - replace hardwired defaults with variables for default conditions
				CtlSetValue((ControlType*)GetObjectPtr(form,DelayingCBID), 0);
				CtlSetValue((ControlType*)GetObjectPtr(form,ReadiedCBID), 0);
				CtlSetValue((ControlType*)GetObjectPtr(form,TakingReadiedCBID), 0);
				CtlSetValue((ControlType*)GetObjectPtr(form,AwareCBID), 1);
				
			} else { // editing an existing character - put current values in fields
				Char numS[maxStrIToALen];

				/* Character's Name Field */
				Char* s;
				MemHandle h = character->getNameHandle(&s);
				FldSet(form,NameFieldID,s);
				MemHandleUnlock(h);

				/* Modifier Field */
				StrIToA(numS, character->getModifier());
				FldSet(form,ModifierFieldID,numS);
				
				// TODO - F2 - Add check boxes for editing Delaying, Readied, Aware statii?
				/* Delaying Check Box */
				/* CtlSetValue(
					(ControlType*)GetObjectPtr(form,DelayingCBID),
					character->isDelaying() 
				); */
				
				/* Effect Name Counter Field */
				StrIToA(numS, character->getCounter());
				FldSet(form,CountFieldID,numS);
				
				/* Character's Duration Field */
				StrIToA(numS, character->getDuration());
				FldSet(form,DurationFieldID,numS);

				/* Check Boxes */
				CtlSetValue((ControlType*)GetObjectPtr(form,DelayingCBID),
							 character->isDelaying());
				CtlSetValue((ControlType*)GetObjectPtr(form,ReadiedCBID),
							 character->isReadied());
				CtlSetValue((ControlType*)GetObjectPtr(form,TakingReadiedCBID), 
							 character->isTakingReadied());
				CtlSetValue((ControlType*)GetObjectPtr(form,AwareCBID),
							 character->isAware());
			}
			/* Finish setting up name field */
			field = (FieldType*) GetObjectPtr(form,NameFieldID);
			// select whole thing
            FldSetSelection(field,0,StrLen(FldGetTextPtr(field)));
			// put focus there
			FrmSetFocus(form, FrmGetObjectIndex(form,NameFieldID) );
			// ...and redraw
			FldDrawField(field);			
            // set up Graffiti shift state to upper shift on
            GrfSetState(false,false,true);
			handled = true;
            break;
        case ctlSelectEvent: // button pushed
            form = FrmGetActiveForm();
            switch (event->data.ctlSelect.controlID) {
				case DoneID:
					form = FrmGetActiveForm();
					{
						/* Validate fields as needed. 
						   Save strings found for assignment, if warranted. */
						Boolean valid = true;
						Char* modifierS = NULL;
						
						// TODO - F2 - Validate new name

						/* Initiative Modifier */
						field = (FieldType*) GetObjectPtr(form,ModifierFieldID);
						if (FldDirty(field)) {
							modifierS = FldGetTextPtr(field);
							if ( StrIsI(modifierS) == false ) {
								FrmAlert(InvalidModifierID);
								valid = false;
							} 
						}

						/* Spell Counter */
						Int32 count = -1;
						field = (FieldType*) GetObjectPtr(form,CountFieldID);
						if (FldDirty(field)) {
							// field is numeric, so count will be non-negative number
							Int32 count = StrAToI(FldGetTextPtr(field));
							if (count > 255) {
								FrmAlert(SpellNumberAlertID);
								valid = false;
							} 
						}

						/* Default duration */
						Int32 duration = -1;
						field = (FieldType*) GetObjectPtr(form,DurationFieldID);
						if (FldDirty(field)) {
							Int32 duration = StrAToI(FldGetTextPtr(field));
							if (duration > 255) {
								FrmAlert(DefaultDurationAlertID);
								valid = false;
							} 
						}

						if (valid == true) {
							if (character == NULL) { // create new character
        						field = (FieldType*) GetObjectPtr(form,NameFieldID);
        						if (FldDirty(field)==false) // user did not touch default name 
									counterCharacterName++;
								Char* name = FldGetTextPtr(field);
								Int16 mod = 
									StrAToI( 
										FldGetTextPtr( 
											(FieldType*) GetObjectPtr(form,ModifierFieldID) 
										) 
									);
								UInt8 count = 
									StrAToI( 
										FldGetTextPtr( 
											(FieldType*) GetObjectPtr(form,CountFieldID) 
										) 
									);
								UInt8 duration = 
									StrAToI( 
										FldGetTextPtr( 
											(FieldType*) GetObjectPtr(form,DurationFieldID) 
										) 
									);
								character = new Character(name,mod,count,duration);
							} else { // edit old character
        						/* Name */
        						field = (FieldType*) GetObjectPtr(form,NameFieldID);
        						if (FldDirty(field)) {
        							character->setName( FldGetTextPtr(field) );
        						}
        						
        						/* Initiative Modifier */
        						if (modifierS != NULL) {
        							character->setModifier( StrAToI(modifierS) );
        						}
        						
        						/* Effect Name Counter */
        						if (count >= 0) {
        							character->setCounter( count );
        						}
        						
        						/* Duration */
        						if (duration >= 0) {
        							character->setDuration( duration );
        						}
							} // end of new/old character conditional
							// Close this form
							FrmReturnToForm(0);
							// If returning to Overview Form, tell it to display this character
							OverviewFormUpdate( character );
						} // end of valid conditional
    				}
					//FreeMemory();
					handled = true;
					break;
				case DeleteID:
					// have user verify
					if (FrmAlert(VerifyDeleteAlertID)==0) {
						if (character == NULL) { // no character to delete, just exit
							FrmReturnToForm(0);
						} else {
							if (character->deactivate()==true) { // character was deactivated
								// exit form
								FrmReturnToForm(0);
								// free object from heap
								delete character;
								// if returning to overview form, update it
								OverviewFormUpdate(NULL);
							}
						}
					}
					handled = true;
					break;
				case CancelID:
					FrmReturnToForm(0);
					handled = true;
					break;
            }
            break; // end of control selected events
		case frmCloseEvent: // form closed
			//FreeMemory();
			break;
        default:
            break;
    }
    return handled;
} // end of function EventHandlerEditCharForm
