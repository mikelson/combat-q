#include "Main.h"

/* 
 * Process input-event to D20 Logo display form.
 */
Boolean EventHandlerLogoForm(EventPtr event)
{
    Boolean handled = false;
    FormType* form;
    switch (event->eType) {
        case frmOpenEvent:
			form = FrmGetActiveForm();
            FrmDrawForm(form);
            handled = true;
            break;
        case ctlSelectEvent: // button pushed
            switch (event->data.ctlSelect.controlID) {
                case (DoneID): 
					FrmGotoTextForm(StringAboutTitleID, StringAboutID);
                    handled = true;
                    break;
            }
            break;
    }
    return handled;
}
